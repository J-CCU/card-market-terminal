# Card Market Terminal — functional MVP v0.1

A **local-first GUI** for MTG and Pokémon card catalog research with SQLite, a developer API, source-backed observations, manual import jobs, and CSV exports. This is a functional starting build, **not a completed Card Hedge Plus clone**.

## Run locally

Requires **Python 3.10+**. In the unpacked folder:

**macOS / Linux**
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python -m uvicorn app.main:app --host 127.0.0.1 --port 8765
```

**Windows PowerShell**
```powershell
py -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8765
```

Open **http://127.0.0.1:8765/** in your browser. Developer API docs are at **http://127.0.0.1:8765/docs**.

The app creates `runtime-data/market.sqlite3` on first launch. To store the database elsewhere, set `CARD_TERMINAL_DATA` to a directory before starting the app. Back up this directory; it lives outside the Python application package.

## First use

1. On Overview, search `Lightning Bolt` and click **Collect MTG**. Scryfall supplies an initial page of matching printings. Result sizes depend on the source.
2. Enter Pokémon archival set code `base1` and click **Import Pokémon set**. Pokémon card names, numbers, and set metadata are downloaded from the community's historic dataset.
3. Browse **Card Explorer**, inspect reference prices if present, and download CSV exports.
4. Disable either source on **Collectors**. Importing is a manual, user-approved operation; there is **no automatic polling** yet.

The app needs internet access for the two manual collectors. The local catalog and API remain usable offline afterward.

## Important limitations

- Scryfall price fields are **reference quotes**. They are not verified transactions, not a tradable buy/sell quote, and have no source-published intraday event timestamp here. For early observations, `source_as_of` is the retrieval *date assumption*, not an independently verified price update time. All imports record a real collection timestamp.
- Pokémon GitHub catalog content is **archival**. The upstream project says it is deprecated; its associated API is scheduled to be shut down in March 2027. This MVP does not call the retiring API and does not invent Pokémon prices. You can later add a sustainable permitted price source.
- The MTG collector uses one Scryfall search page per user action. It is **not** an exhaustive catalog import. No rate-limit bypass, background crawling, scraping, or bulk redistribution is implemented. For full MTG import, the next enhancement should use a documented Scryfall bulk dataset and MTGJSON, after checking current licensing and resource limits.
- No actual sold transaction feed, full historical price backfill, automatic scheduling, model, grading feed, authenticated public API, alerts, webhooks, or cloud uptime SLA yet.
- The local service is **not authenticated**. Keep it bound to 127.0.0.1. Do not expose its endpoints to the internet without adding authentication and authorization.
- Confirm upstream licensing and commercial redistribution rights before distributing their data or card images to other people.
- Do not put credentials or proprietary paid API data into config files.

## API endpoints

- `GET /api/v1/health`
- `GET /api/v1/summary`
- `GET /api/v1/cards?q=...&game=mtg|pokemon|all`
- `GET /api/v1/cards/{id}`
- `POST /api/v1/collect/mtg` with `{"query":"Lightning Bolt"}`
- `POST /api/v1/collect/pokemon` with `{"set_code":"base1"}`
- `PUT /api/v1/sources/mtg` or `/pokemon` with `{"enabled":false}`
- `GET /api/v1/export/cards.csv`
- `GET /api/v1/export/observations.csv`

## Next milestones

1. MTG full bulk catalog and MTGJSON daily pricing ingestion with date-accurate provenance.
2. Pokémon current catalog data source with verified long-term zero-cost access and permitted market pricing.
3. Migrations, fuller printing/variant identity, normalization, checkpointing and tests.
4. Configurable scheduling, rate-limit-aware source monitors and sustained reliability tests.
5. API-key scopes, caching, exports, webhooks, and later analytics/forecasting/buy-floor systems.

## Sources

- Scryfall: https://scryfall.com/docs/api
- MTGJSON: https://mtgjson.com/
- Pokémon legacy catalog: https://github.com/PokemonTCG/pokemon-tcg-data
