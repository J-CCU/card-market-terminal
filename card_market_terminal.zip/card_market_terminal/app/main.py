"""Card Market Terminal: local-first, real-data-only market catalog MVP."""
from __future__ import annotations
import csv
import io
import json
import os
import sqlite3
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

import httpx
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import HTMLResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE = Path(__file__).resolve().parent
DATA = Path(os.environ.get("CARD_TERMINAL_DATA", str(BASE.parent / "runtime-data"))).expanduser().resolve()
DATA.mkdir(parents=True, exist_ok=True)
DB = DATA / "market.sqlite3"
LOCK = threading.RLock()
app = FastAPI(title="Card Market Terminal", version="0.1.0", description="Local-only catalog and source-backed market observations")
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")


def utc():
    return datetime.now(timezone.utc).isoformat()


def connect():
    con = sqlite3.connect(DB, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA busy_timeout=30000")
    return con


def init_db():
    with connect() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS cards (
            id TEXT PRIMARY KEY, game TEXT NOT NULL, name TEXT NOT NULL,
            set_name TEXT, set_code TEXT, collector_number TEXT, rarity TEXT,
            language TEXT DEFAULT 'en', finish TEXT, image_url TEXT,
            released_at TEXT, source TEXT NOT NULL, source_url TEXT,
            metadata_json TEXT, updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_cards_game_name ON cards(game, name);
        CREATE INDEX IF NOT EXISTS idx_cards_set ON cards(game, set_code, collector_number);
        CREATE TABLE IF NOT EXISTS observations (
            id INTEGER PRIMARY KEY AUTOINCREMENT, card_id TEXT NOT NULL,
            source TEXT NOT NULL, price_type TEXT NOT NULL, price_field TEXT NOT NULL,
            condition TEXT NOT NULL DEFAULT 'unspecified', currency TEXT NOT NULL DEFAULT 'USD',
            amount REAL NOT NULL CHECK(amount >= 0), source_as_of TEXT, collected_at TEXT NOT NULL,
            FOREIGN KEY(card_id) REFERENCES cards(id),
            UNIQUE(card_id,source,price_type,price_field,condition,source_as_of)
        );
        CREATE INDEX IF NOT EXISTS idx_obs_card_date ON observations(card_id,collected_at DESC);
        CREATE TABLE IF NOT EXISTS collector_runs (
            id INTEGER PRIMARY KEY AUTOINCREMENT, source TEXT NOT NULL, started_at TEXT NOT NULL,
            finished_at TEXT, status TEXT NOT NULL, records INTEGER NOT NULL DEFAULT 0, error TEXT
        );
        CREATE TABLE IF NOT EXISTS config (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        """)
        con.execute("INSERT OR IGNORE INTO config VALUES ('mtg_enabled','true')")
        con.execute("INSERT OR IGNORE INTO config VALUES ('pokemon_enabled','true')")

init_db()


def rows(sql, args=()):
    with connect() as con:
        return [dict(x) for x in con.execute(sql, args).fetchall()]


def source_is_enabled(game):
    k = 'mtg_enabled' if game == 'mtg' else 'pokemon_enabled'
    x = rows('SELECT value FROM config WHERE key=?',(k,))
    return bool(x and x[0]['value']=='true')


def save_card(con, card):
    con.execute("""INSERT INTO cards(id,game,name,set_name,set_code,collector_number,rarity,language,finish,image_url,released_at,source,source_url,metadata_json,updated_at)
        VALUES (:id,:game,:name,:set_name,:set_code,:collector_number,:rarity,:language,:finish,:image_url,:released_at,:source,:source_url,:metadata_json,:updated_at)
        ON CONFLICT(id) DO UPDATE SET name=excluded.name,set_name=excluded.set_name,set_code=excluded.set_code,
        collector_number=excluded.collector_number,rarity=excluded.rarity,language=excluded.language,finish=excluded.finish,
        image_url=excluded.image_url,released_at=excluded.released_at,source=excluded.source,source_url=excluded.source_url,
        metadata_json=excluded.metadata_json,updated_at=excluded.updated_at""", card)


def save_price(con, card_id, source, field, amount, source_as_of, collected_at, price_type='reference_quote'):
    if isinstance(amount,(int,float)) and not isinstance(amount,bool) and amount>=0:
        con.execute("""INSERT OR IGNORE INTO observations(card_id,source,price_type,price_field,condition,currency,amount,source_as_of,collected_at)
        VALUES(?,?,?,?,?,?,?,?,?)""", (card_id,source,price_type,field,'unspecified','USD',float(amount),source_as_of,collected_at))


def scryfall_card(c):
    image=(c.get('image_uris') or {}).get('normal')
    if not image and c.get('card_faces'):
        image=(c['card_faces'][0].get('image_uris') or {}).get('normal')
    now=utc()
    return dict(id='mtg:'+str(c['id']),game='mtg',name=c.get('name','Unknown'),set_name=c.get('set_name'),
                set_code=c.get('set'),collector_number=c.get('collector_number'),rarity=c.get('rarity'),
                language=c.get('lang','en'),finish=','.join(c.get('finishes') or []),image_url=image,
                released_at=c.get('released_at'),source='Scryfall',source_url=c.get('scryfall_uri'),
                metadata_json=json.dumps({'oracle_id':c.get('oracle_id'),'layout':c.get('layout'),'prices':c.get('prices',{})}),updated_at=now)


def pokemon_card(c):
    set_data=c.get('set') or {}
    set_code=set_data.get('id') or c.get('_set_id')
    images=c.get('images') or {}
    card_id=str(c.get('id') or f"{set_code}-{c.get('number')}")
    return dict(id='pokemon:'+card_id,game='pokemon',name=c.get('name','Unknown'),set_name=set_data.get('name') or c.get('_set_name'),
                set_code=set_code,collector_number=c.get('number'),rarity=c.get('rarity'),language='en',finish=None,
                image_url=images.get('small') or images.get('large'),released_at=set_data.get('releaseDate'),
                source='PokemonTCG legacy dataset',source_url='https://github.com/PokemonTCG/pokemon-tcg-data',
                metadata_json=json.dumps({'supertype':c.get('supertype'),'subtypes':c.get('subtypes',[]),'legacy_snapshot':True}),updated_at=utc())


def run_record(source, fn):
    with LOCK:
        with connect() as con:
            run_id=con.execute('INSERT INTO collector_runs(source,started_at,status) VALUES(?,?,?)',(source,utc(),'running')).lastrowid
        try:
            count=fn()
            with connect() as con:
                con.execute('UPDATE collector_runs SET finished_at=?,status=?,records=? WHERE id=?',(utc(),'completed',count,run_id))
            return {'status':'completed','source':source,'records':count,'run_id':run_id}
        except Exception as e:
            with connect() as con:
                con.execute('UPDATE collector_runs SET finished_at=?,status=?,error=? WHERE id=?',(utc(),'error',str(e)[:700],run_id))
            raise


class SearchRequest(BaseModel):
    query: str

class PokeImport(BaseModel):
    set_code: str = 'base1'

class Toggle(BaseModel):
    enabled: bool

@app.get('/',response_class=HTMLResponse)
def home():
    return (BASE/'static'/'index.html').read_text()

@app.get('/api/v1/health')
def health():
    return {'status':'ok','database':str(DB),'time':utc()}

@app.get('/api/v1/summary')
def summary():
    totals=rows('SELECT game, COUNT(*) AS cards FROM cards GROUP BY game')
    obs=rows('SELECT count(*) AS count FROM observations')[0]['count']
    return {'games':{'mtg':next((x['cards'] for x in totals if x['game']=='mtg'),0),
                     'pokemon':next((x['cards'] for x in totals if x['game']=='pokemon'),0)},
            'observations':obs,'runs':rows('SELECT * FROM collector_runs ORDER BY id DESC LIMIT 8'),
            'sources': [{'id':'mtg','name':'Scryfall search','enabled':source_is_enabled('mtg'),'mode':'live search; public price references'},
                        {'id':'pokemon','name':'PokemonTCG legacy GitHub','enabled':source_is_enabled('pokemon'),'mode':'archival catalog only; not current pricing'}]}

@app.get('/api/v1/cards')
def search_cards(q: str='',game: str='all',limit: int=Query(60,ge=1,le=200),offset:int=Query(0,ge=0)):
    sql='SELECT id,game,name,set_name,set_code,collector_number,rarity,image_url,source,updated_at FROM cards WHERE name LIKE ? ESCAPE "\\"'
    escaped=q.replace('\\','\\\\').replace('%','\\%').replace('_','\\_')
    args=['%'+escaped+'%']
    if game in ['mtg','pokemon']:
        sql+=' AND game=?';args.append(game)
    sql+=' ORDER BY name ASC, set_code ASC LIMIT ? OFFSET ?';args.extend([limit,offset])
    return {'items':rows(sql,args),'limit':limit,'offset':offset}

@app.get('/api/v1/cards/{card_id:path}')
def card_detail(card_id: str):
    result=rows('SELECT * FROM cards WHERE id=?',(card_id,))
    if not result:raise HTTPException(404,'Card not found')
    card=result[0];card['metadata']=json.loads(card.pop('metadata_json') or '{}')
    card['observations']=rows('SELECT source,price_type,price_field,amount,currency,source_as_of,collected_at FROM observations WHERE card_id=? ORDER BY collected_at DESC LIMIT 250',(card_id,))
    return card

@app.post('/api/v1/collect/mtg')
def collect_mtg(request: SearchRequest):
    if not source_is_enabled('mtg'):raise HTTPException(409,'MTG connector disabled')
    query=request.query.strip()
    if len(query)<2 or len(query)>100:raise HTTPException(400,'Enter a card name (2-100 characters)')
    def job():
        with httpx.Client(timeout=35,headers={'User-Agent':'CardMarketTerminal/0.1 (personal research app)','Accept':'application/json'}) as client:
            resp=client.get('https://api.scryfall.com/cards/search',params={'q':query,'unique':'prints','order':'name'})
            if resp.status_code==404:return 0
            resp.raise_for_status()
            payload=resp.json();items=payload.get('data',[])
            # Deliberately one page per approved user-triggered fetch. Avoid automatic high-volume API crawling.
            with connect() as con:
                for c in items:
                    card=scryfall_card(c);save_card(con,card)
                    source_day=utc()[:10]  # collection date only; upstream quote timestamp is unknown
                    for field,raw in (c.get('prices') or {}).items():
                        if raw is not None:
                            try:save_price(con,card['id'],'Scryfall',field,float(raw),source_day,card['updated_at'])
                            except (TypeError,ValueError):pass
            return len(items)
    try:return run_record('Scryfall',job)
    except httpx.HTTPStatusError as e:raise HTTPException(502,'Scryfall HTTP '+str(e.response.status_code))
    except httpx.HTTPError:raise HTTPException(502,'Unable to reach Scryfall')

@app.post('/api/v1/collect/pokemon')
def collect_pokemon(request: PokeImport):
    if not source_is_enabled('pokemon'):raise HTTPException(409,'Pokémon connector disabled')
    code=request.set_code.strip().lower()
    if not code or len(code)>25 or not all(c.isalnum() or c=='-' for c in code):
        raise HTTPException(400,'Set code must contain only letters, numbers, or hyphens')
    def job():
        url=f'https://raw.githubusercontent.com/PokemonTCG/pokemon-tcg-data/master/cards/en/{code}.json'
        with httpx.Client(timeout=60,follow_redirects=False,headers={'User-Agent':'CardMarketTerminal/0.1'}) as client:
            response=client.get(url)
            if response.status_code==404:raise ValueError('Unknown legacy set code: '+code)
            response.raise_for_status()
            if len(response.content)>12_000_000:raise ValueError('Dataset exceeds size limit')
            payload=response.json()
        if not isinstance(payload,list):raise ValueError('Unexpected legacy dataset format')
        with connect() as con:
            for c in payload:
                c['_set_id']=code
                save_card(con,pokemon_card(c))
        return len(payload)
    try:return run_record('PokemonTCG GitHub archive',job)
    except ValueError as e:raise HTTPException(400,str(e))
    except httpx.HTTPError:raise HTTPException(502,'Unable to reach Pokémon archival dataset')

@app.put('/api/v1/sources/{game}')
def set_source(game:str,toggle:Toggle):
    if game not in ('mtg','pokemon'):raise HTTPException(404,'Unknown source')
    with connect() as con:
        con.execute('UPDATE config SET value=? WHERE key=?',('true' if toggle.enabled else 'false',game+'_enabled'))
    return {'game':game,'enabled':toggle.enabled}

@app.get('/api/v1/export/cards.csv')
def export_cards(game:str='all'):
    if game not in ('all','mtg','pokemon'):raise HTTPException(400,'Invalid game')
    sql='SELECT id,game,name,set_name,set_code,collector_number,rarity,source,updated_at FROM cards'
    args=()
    if game!='all':sql+=' WHERE game=?';args=(game,)
    sql+=' ORDER BY name'
    output=io.StringIO();w=csv.writer(output)
    w.writerow(['id','game','name','set_name','set_code','collector_number','rarity','source','updated_at'])
    with connect() as con:
        for line in con.execute(sql,args):w.writerow(list(line))
    return Response(output.getvalue(),media_type='text/csv',headers={'Content-Disposition':'attachment; filename="cards.csv"'})

@app.get('/api/v1/export/observations.csv')
def export_prices():
    output=io.StringIO();w=csv.writer(output)
    w.writerow(['card_id','source','price_type','price_field','condition','amount','currency','source_as_of','collected_at'])
    with connect() as con:
        for line in con.execute('SELECT card_id,source,price_type,price_field,condition,amount,currency,source_as_of,collected_at FROM observations ORDER BY card_id,collected_at'):
            w.writerow(list(line))
    return Response(output.getvalue(),media_type='text/csv',headers={'Content-Disposition':'attachment; filename="observations.csv"'})
